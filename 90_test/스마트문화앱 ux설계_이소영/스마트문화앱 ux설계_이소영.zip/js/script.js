







$(document).ready(function(){
   
$('.slide').bxSlider({





    
    autoControls: false,

    auto: true,
  
    stopAutoOnClick: true,
    autoStart: true,
 
    autoHover: true,
    
    autoDelay: 4000
  
});

}); 